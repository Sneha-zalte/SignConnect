
import os
import base64
import io
import time
from typing import List, Tuple

import numpy as np
import cv2
from flask import Flask, render_template, request
from flask_socketio import SocketIO, join_room, leave_room, emit
import mediapipe as mp

# -----------------------------
# App & Socket Setup
# -----------------------------
app = Flask(__name__, static_folder="static", template_folder="templates")
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "devkey")

# Allow any origin for demo; in production, restrict to your domain
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="eventlet")

# ICE server config via env; defaults include public STUN
DEFAULT_ICE = [
    {"urls": "stun:stun.l.google.com:19302"},
    {"urls": "stun:stun1.l.google.com:19302"},
]

turn_url = os.environ.get("TURN_URL")          # e.g., "turn:global.turn.twilio.com:3478?transport=udp"
turn_username = os.environ.get("TURN_USERNAME")
turn_password = os.environ.get("TURN_PASSWORD")

ICE_SERVERS = DEFAULT_ICE.copy()
if turn_url and turn_username and turn_password:
    ICE_SERVERS.append({
        "urls": turn_url,
        "username": turn_username,
        "credential": turn_password
    })

# -----------------------------
# MediaPipe Hands
# -----------------------------
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=1,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

# -----------------------------
# Gesture Classification (heuristic)
# -----------------------------
# landmarks: list of 21 (x,y,z) normalized to [0,1]
# We classify: OPEN_PALM, FIST, V_SIGN, THUMBS_UP, NONE

CLASSES = ["OPEN_PALM", "FIST", "V_SIGN", "THUMBS_UP", "NONE"]

def _fingers_up(landmarks: List[Tuple[float, float, float]]) -> np.ndarray:
    # Based on y-coordinates (assuming portrait video, y increases downward)
    # Compare fingertip y with PIP/MCP y for fingers; for thumb, compare x distances.
    # Landmarks index reference (MediaPipe):
    # Thumb: 1-4, Index:5-8, Middle:9-12, Ring:13-16, Pinky:17-20
    lm = np.array(landmarks)  # shape (21,3)
    y = lm[:,1]; x = lm[:,0]
    def up(tip, pip, mcp):
        return y[tip] < y[pip] < y[mcp]  # tip above pip above mcp
    
    # For thumb, check x separation relative to wrist (0) depending on left/right by comparing x[5] and x[17]
    left_hand = x[5] < x[17]
    if left_hand:
        thumb_up = x[4] < x[3] < x[2]
    else:
        thumb_up = x[4] > x[3] > x[2]

    index_up  = up(8, 6, 5)
    middle_up = up(12,10,9)
    ring_up   = up(16,14,13)
    pinky_up  = up(20,18,17)
    return np.array([thumb_up, index_up, middle_up, ring_up, pinky_up], dtype=np.float32)

def classify_landmarks(landmarks: List[Tuple[float,float,float]]):
    feats = _fingers_up(landmarks)
    t,i,m,r,p = feats
    label = "NONE"
    if i and m and r and p and t:
        label = "OPEN_PALM"
    elif not i and not m and not r and not p and not t:
        label = "FIST"
    elif i and m and not r and not p:
        label = "V_SIGN"
    elif t and not i and not m and not r and not p:
        label = "THUMBS_UP"
    conf = float((feats.mean() if label=="OPEN_PALM" else
                  1.0 - feats.mean() if label=="FIST" else
                  (i+m)/2 if label=="V_SIGN" else
                  t if label=="THUMBS_UP" else 0.5))
    text_map = {
        "OPEN_PALM": "Hello / Hi",
        "FIST": "Stop / Yes",
        "V_SIGN": "Victory / Peace",
        "THUMBS_UP": "Good / OK",
        "NONE": ""
    }
    return {
        "label": label,
        "text": text_map[label],
        "confidence": round(conf, 2),
        "features": feats.astype(int).tolist()
    }

# -----------------------------
# Routes
# -----------------------------
@app.route("/")
def index():
    return render_template("index.html", ice_servers=ICE_SERVERS)

# -----------------------------
# Socket.IO Events
# -----------------------------
@socketio.on("join")
def on_join(data):
    room = data.get("room", "demo")
    join_room(room)
    emit("joined", {"room": room, "sid": request.sid}, to=request.sid)
    emit("peer-joined", {"sid": request.sid}, room=room, include_self=False)

@socketio.on("leave")
def on_leave(data):
    room = data.get("room", "demo")
    leave_room(room)
    emit("peer-left", {"sid": request.sid}, room=room, include_self=False)

@socketio.on("signal")
def on_signal(data):
    # Relay WebRTC signaling to peers in room
    room = data.get("room", "demo")
    emit("signal", data, room=room, include_self=False)

@socketio.on("frame")
def on_frame(data):
    """Receive base64 frame, run MediaPipe, send prediction."""
    try:
        room = data.get("room", "demo")
        b64 = data.get("image","")
        if not b64:
            return
        # decode base64
        header, _, b64data = b64.partition(",")
        img_bytes = base64.b64decode(b64data)
        image = cv2.imdecode(np.frombuffer(img_bytes, dtype=np.uint8), cv2.IMREAD_COLOR)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        result = hands.process(image)
        if result.multi_hand_landmarks:
            hand = result.multi_hand_landmarks[0]
            lms = [(lm.x, lm.y, lm.z) for lm in hand.landmark]
            pred = classify_landmarks(lms)
        else:
            pred = {"label":"NONE","text":"","confidence":0.0,"features":[0,0,0,0,0]}
        emit("prediction", pred, room=room)
    except Exception as e:
        emit("prediction", {"error": str(e)}, room=data.get("room","demo"))

# -----------------------------
# Main
# -----------------------------
if __name__ == "__main__":
    # Bind 0.0.0.0 for public hosting; set PORT from env (Railway/Render use it)
    port = int(os.environ.get("PORT", "8000"))
    # eventlet is recommended for Flask-SocketIO websockets
    socketio.run(app, host="0.0.0.0", port=port, debug=False)
