# Sign Translator (Internet-Ready)

This is a Flask + Socket.IO + WebRTC version of your Sign Translator that works **over the internet**.

## What's new
- **Public signaling** via Flask-SocketIO (WebSockets)
- **STUN/TURN** configurable via environment variables
- **0.0.0.0 bind** and `PORT` support for cloud deploys
- Minimal, modern UI

## Run locally
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python app.py
# open http://localhost:8000
```
Open the page on **two different devices** (same URL) and use the same **Room ID**.

## Deploy (Render/Railway/VPS)
1. **Create a new web service** and point it to this repo/folder.
2. Set **Build Command** (if needed): `pip install -r requirements.txt`
3. Set **Start Command** (if needed): `python app.py`
4. Add environment variables if you have a TURN provider:
   - `TURN_URL` (e.g., `turn:your.turn.server:3478?transport=udp`)
   - `TURN_USERNAME`
   - `TURN_PASSWORD`
5. Add a `SECRET_KEY` (any random string).

The app reads `PORT` from env (default `8000`) and serves on `0.0.0.0`.

## ICE servers
By default the app uses Google STUNs. For reliability across strict networks, add a **TURN** server via the environment variables above.

## Notes
- MediaPipe runs **server-side** from the frames your browser sends (5 FPS).
- WebRTC media flows peer-to-peer when possible; TURN may relay when needed.
