
const socket = io();

let pc = null;
let localStream = null;
let room = null;
const localVideo = document.getElementById("localVideo");
const remoteVideo = document.getElementById("remoteVideo");
const joinBtn = document.getElementById("joinBtn");
const leaveBtn = document.getElementById("leaveBtn");
const signText = document.getElementById("signText");
const conf = document.getElementById("conf");
const speakToggle = document.getElementById("speakToggle");
const canvas = document.getElementById("captureCanvas");
const ctx = canvas.getContext("2d");
let frameTimer = null;

// -----------------------------
// WebRTC helpers
// -----------------------------
async function setupMedia() {
  localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
  localVideo.srcObject = localStream;
}

function makePeerConnection() {
  pc = new RTCPeerConnection({ iceServers: window.ICE_SERVERS });

  // Local tracks
  localStream.getTracks().forEach(track => pc.addTrack(track, localStream));

  // ICE candidates
  pc.onicecandidate = e => {
    if (e.candidate) {
      socket.emit("signal", { room, type: "candidate", candidate: e.candidate });
    }
  };

  // Remote stream
  pc.ontrack = e => {
    remoteVideo.srcObject = e.streams[0];
  };

  return pc;
}

async function makeOffer() {
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  socket.emit("signal", { room, type: "offer", sdp: offer });
}

async function makeAnswer(offer) {
  await pc.setRemoteDescription(new RTCSessionDescription(offer));
  const answer = await pc.createAnswer();
  await pc.setLocalDescription(answer);
  socket.emit("signal", { room, type: "answer", sdp: answer });
}

// -----------------------------
// Signaling
// -----------------------------
socket.on("joined", ({ room: r }) => {
  console.log("Joined room", r);
});

socket.on("peer-joined", async () => {
  // If we are the second peer, create an offer
  if (pc) {
    await makeOffer();
  }
});

socket.on("peer-left", () => {
  if (pc) {
    pc.close();
    pc = null;
  }
  remoteVideo.srcObject = null;
});

socket.on("signal", async (data) => {
  if (!pc) return;
  if (data.type === "offer") {
    await makeAnswer(data.sdp);
  } else if (data.type === "answer") {
    await pc.setRemoteDescription(new RTCSessionDescription(data.sdp));
  } else if (data.type === "candidate") {
    try {
      await pc.addIceCandidate(new RTCIceCandidate(data.candidate));
    } catch (err) {
      console.error("Error adding ICE candidate", err);
    }
  }
});

// -----------------------------
function speak(text) {
  if (!('speechSynthesis' in window)) return;
  const utter = new SpeechSynthesisUtterance(text);
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(utter);
}

socket.on("prediction", (p) => {
  if (p.error) {
    console.warn("Prediction error:", p.error);
    return;
  }
  signText.textContent = p.text || p.label || "—";
  conf.textContent = p.confidence != null ? p.confidence : "—";
  if (speakToggle.checked && p.text) speak(p.text);
});

// -----------------------------
// Frame sending to server (5 FPS)
// -----------------------------
function startStreamingFrames() {
  stopStreamingFrames();
  frameTimer = setInterval(() => {
    if (!localVideo.videoWidth) return;
    canvas.width = 320;
    canvas.height = 240;
    ctx.drawImage(localVideo, 0, 0, canvas.width, canvas.height);
    const dataURL = canvas.toDataURL("image/jpeg", 0.6);
    socket.emit("frame", { room, image: dataURL });
  }, 200);
}

function stopStreamingFrames() {
  if (frameTimer) {
    clearInterval(frameTimer);
    frameTimer = null;
  }
}

// -----------------------------
// Buttons
// -----------------------------
joinBtn.addEventListener("click", async () => {
  room = document.getElementById("room").value.trim() || "global-demo";
  joinBtn.disabled = true;
  await setupMedia();
  makePeerConnection();
  socket.emit("join", { room });
  startStreamingFrames();
  leaveBtn.disabled = false;
});

leaveBtn.addEventListener("click", () => {
  socket.emit("leave", { room });
  stopStreamingFrames();
  if (pc) {
    pc.close();
    pc = null;
  }
  remoteVideo.srcObject = null;
  joinBtn.disabled = false;
  leaveBtn.disabled = true;
});
